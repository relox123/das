import os
os.system("cd scraper && python3 __main__.py")